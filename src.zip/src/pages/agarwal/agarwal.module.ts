import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AgarwalPage } from './agarwal';

@NgModule({
  declarations: [
    AgarwalPage,
  ],
  imports: [
    IonicPageModule.forChild(AgarwalPage),
  ],
  exports: [
    AgarwalPage
  ]
})
export class AgarwalPageModule {}
