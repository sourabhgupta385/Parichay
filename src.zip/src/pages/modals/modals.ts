import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { IonicPage, NavController, NavParams, ViewController } from 'ionic-angular';
import { DatabaseProvider } from '../../providers/database/database';
import { ImageProvider } from '../../providers/image/image';
import { PreloaderProvider } from '../../providers/preloader/preloader';
import * as firebase from 'firebase';

@IonicPage()
@Component({
  selector: 'page-modals',
  templateUrl: 'modals.html',
})
export class ModalsPage {

   public form             : any;
   public _image    	     : any;
   public movies           : any;
   public age              : any;
   public dateofbirth              : any;
   public today              : any;
   public movieImage       : any     = '';

   constructor(
      public navCtrl        : NavController,
      public params         : NavParams,
      private _FB 	        : FormBuilder,
      private _IMG          : ImageProvider,
      public viewCtrl       : ViewController,
      private _LOADER       : PreloaderProvider,
      private _DB           : DatabaseProvider) {

      this.form 		= _FB.group({
         '_name' 	           	: ['', Validators.required],
         '_city'              : ['', Validators.required],
         '_dob'               : ['', Validators.required],
         '_birthtime'         : ['', Validators.required],
         '_birthplace'        : ['', Validators.required],
         '_gender'            : ['', Validators.required],
         '_education'         : ['', Validators.required],
         '_occupation'        : ['', Validators.required],
         '_monthlyincome'     : ['', Validators.required],
         '_fathername'        : ['', Validators.required],
         '_fatheroccupation'  : ['', Validators.required],
         '_brother'           : ['', Validators.required],
         '_sister'            : ['', Validators.required],
         '_contact'           : ['', Validators.required],
         '_image'             : ['', Validators.required],
         '_caste'             : ['', Validators.required],
       });
       
       this.movies = firebase.database().ref('films/');
  }

  	saveMovie(val)
   {

      this._LOADER.displayPreloader();
      
      this.dateofbirth = new Date(this.form.controls["_dob"].value);
      this.today = new Date();
      this.age = this.today.getFullYear() - this.dateofbirth.getFullYear();
      
      let title	            : string		    = this.form.controls["_name"].value,
      	  image             : string        = this._image,
          city              : string        = this.form.controls["_city"].value,
          dob               : string        = this.form.controls["_dob"].value,
          _age               : any           = this.age,
          birthtime         : string        = this.form.controls["_birthtime"].value,
          birthplace        : string        = this.form.controls["_birthplace"].value,
          gender            : string        = this.form.controls["_gender"].value,
          education         : string        = this.form.controls["_education"].value,
          occupation        : string        = this.form.controls["_occupation"].value,
          monthlyincome     : string        = this.form.controls["_monthlyincome"].value,
          fathername        : string        = this.form.controls["_fathername"].value,
          fatheroccupation  : string        = this.form.controls["_fatheroccupation"].value,
          brother           : string        = this.form.controls["_brother"].value,
          sister            : string        = this.form.controls["_sister"].value,
          contact           : string        = this.form.controls["_contact"].value,
          caste             : string        = this.form.controls["_caste"].value;

      	  this._DB.uploadImage(image)
         .then((snapshot : any) =>
         {
            let uploadedImage : any = snapshot.downloadURL;

            this._DB.addToDatabase({
	           title            : title,
             city             : city,
             dob              : dob,
             age              : _age,
             birthtime        : birthtime,
             birthplace       : birthplace,
             gender           : gender,
             education        : education,
             occupation       : occupation,
             monthlyincome    : monthlyincome,
             fathername       : fathername,
             fatheroccupation : fatheroccupation,
             brother          : brother,
             sister           : sister,
             contact          : contact,
             caste            : caste,              
	           image            : uploadedImage,
	           })
            .then((data) =>
            {
               
            });
         });

         this.closeModal(true);
    }

    closeModal(val = null)
   {
      this.viewCtrl.dismiss(val);
   }

   selectImage()
   {
      this._IMG.selectImage()
      .then((data) =>
      {
         this._image = data;
      });
   }
}
