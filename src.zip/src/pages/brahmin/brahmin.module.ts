import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { BrahminPage } from './brahmin';

@NgModule({
  declarations: [
    BrahminPage,
  ],
  imports: [
    IonicPageModule.forChild(BrahminPage),
  ],
  exports: [
    BrahminPage
  ]
})
export class BrahminPageModule {}
