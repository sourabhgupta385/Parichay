import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { JainPage } from './jain';

@NgModule({
  declarations: [
    JainPage,
  ],
  imports: [
    IonicPageModule.forChild(JainPage),
  ],
  exports: [
    JainPage
  ]
})
export class JainPageModule {}
