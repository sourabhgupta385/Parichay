import { Component } from '@angular/core';
import { NavController , Platform, ModalController } from 'ionic-angular';
import { DatabaseProvider } from '../../providers/database/database';
import { ImageProvider } from '../../providers/image/image';
import { PreloaderProvider } from '../../providers/preloader/preloader';
import * as firebase from 'firebase';
import { Http } from '@angular/http';
import 'rxjs/Rx';



@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  public movies    : any;
	
  constructor(
                public navCtrl       : NavController , 
  				private platform     : Platform,
                private modalCtrl    : ModalController,
                private _IMG         : ImageProvider,
                private _LOADER      : PreloaderProvider,
                private _DB          : DatabaseProvider ) {
  }

  ionViewDidEnter(){
    this.platform.ready().then(() =>{
          this.loadAndParseMovies();
      }).catch((err : Error) =>{
            console.log(err.message);
         });               
  }

  doRefresh(refresher) {
    this.loadAndParseMovies();
    setTimeout(() => {
      console.log('Async operation has ended');
      refresher.complete();
    }, 2000);
  }

  loadAndParseMovies(){
    this.movies = this._DB.renderMovies(); 
  }

  addRecord(){
    let modal = this.modalCtrl.create('ModalsPage');
    modal.onDidDismiss((data) =>{
        if(data){
            this._LOADER.displayPreloader();
            this.loadAndParseMovies();
        }
    });
    modal.present();
  }

  openModal(movie){  
    let modal = this.modalCtrl.create('DescriptionPage' ,{movie_obj :movie});
    modal.onDidDismiss((data) =>{
        if(data){
            this._LOADER.displayPreloader();
            this.loadAndParseMovies();
        }
    });
    modal.present();
  }
}
