import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RajputPage } from './rajput';

@NgModule({
  declarations: [
    RajputPage,
  ],
  imports: [
    IonicPageModule.forChild(RajputPage),
  ],
  exports: [
    RajputPage
  ]
})
export class RajputPageModule {}
