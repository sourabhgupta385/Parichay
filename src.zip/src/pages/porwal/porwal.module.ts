import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PorwalPage } from './porwal';

@NgModule({
  declarations: [
    PorwalPage,
  ],
  imports: [
    IonicPageModule.forChild(PorwalPage),
  ],
  exports: [
    PorwalPage
  ]
})
export class PorwalPageModule {}
