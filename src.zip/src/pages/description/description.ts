import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController  } from 'ionic-angular';
import { PreloaderProvider } from '../../providers/preloader/preloader';
import * as firebase from 'firebase';

@IonicPage()
@Component({
  selector: 'page-description',
  templateUrl: 'description.html',
})
export class DescriptionPage {

	public movie : any;

  constructor(
  				public navCtrl     : NavController, 
  				public navParams   : NavParams,
  				public viewCtrl    : ViewController,
                private _LOADER    : PreloaderProvider) {

  				this.movie = navParams.get('movie_obj');
  }

  ionViewDidLoad() {
  }

  closeModal(val = null)
   {
      this.viewCtrl.dismiss(val);
   }

}
