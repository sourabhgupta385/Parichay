import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { LoadingController } from 'ionic-angular';
import 'rxjs/add/operator/map';

/*
  Generated class for the PreloaderProvider provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular DI.
*/
@Injectable()
export class PreloaderProvider {

  constructor(public http: Http , public loadingCtrl : LoadingController) {
    console.log('Hello PreloaderProvider Provider');
  }

  displayPreloader() : void
   {
      let loading = this.loadingCtrl.create({
         content: 'Hold On For A While...',
         duration: 3000
      });

      loading.present();

   }

}
